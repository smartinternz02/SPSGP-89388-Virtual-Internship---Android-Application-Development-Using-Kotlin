# Virtual Internship - Android Application Development Using Kotlin MAIN PROJECT 1

## An Android Application To Search Nearby Business Using Kotlin

A mobile app is built where the user can search for his nearby locations based on his requirement. Whenever the user gives input of business type like a hotel, petrol pumps, hospitals, etc. using Place API and as a response we obtain the co-ordinates that are marked on the Google map.
